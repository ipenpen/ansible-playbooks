document.addEventListener('DOMContentLoaded', function () {
  var zoomOutButton = document.getElementById('zoomOut');
  zoomOutButton.addEventListener('click', function () {

    function modifyDOM() {
      const rate = 2;
      document.getElementById("game-canvas").width = document.getElementById("game-canvas").width * rate;
      document.getElementById("game-canvas").height = document.getElementById("game-canvas").height * rate;
    }
    chrome.tabs.executeScript({
      code: '(' + modifyDOM + ')();'
    }, (results) => {
    });
  }, false);
}, false);
