#!/usr/bin/env bash

# Starts PokemonGo-Bot
config=""

if [ ! -z $1 ]; then
    config=$1
else
    config="./configs/config2.json"
    if [ ! -f ${config} ]; then
        echo -e "There's no ./configs/config2.json file"
        echo -e "Please create one or use another config file"
        echo -e "./run.sh [path/to/config/file]"
        exit 1
    fi
fi

until (python pokecli.py --config ${config}); do
    echo "Process crashed with exit code $?.  Respawning.." >&2
    sleep 300
done
