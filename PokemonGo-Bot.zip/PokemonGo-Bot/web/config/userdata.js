// MUST CONFIGURE THE USER ARRAY AND GOOGLE MAPS API KEY.
// YOU CAN GET A KEY HERE: https://developers.google.com/maps/documentation/javascript/get-api-key
var userInfo = {
	users: ["pokego.erika123@gmail.com", "pokego.taro123@gmail.com"],
	userZoom: true,
	zoom: 16,
	userFollow: true,
	gMapsAPIKey: "AIzaSyAskbyFcNQ1QPQkPVOdnrGGM8BNF0a-tb8",
	botPath: true,
	actionsEnabled: true
};
